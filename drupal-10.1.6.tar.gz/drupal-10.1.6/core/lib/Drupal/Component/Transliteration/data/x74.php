<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'han', 'xuan', 'yan', 'qiu', 'xuan', 'lang', 'li', 'xiu', 'fu', 'liu', 'ya', 'xi', 'ling', 'li', 'jin', 'lian',
  0x10 => 'suo', 'suo', 'feng', 'wan', 'dian', 'pin', 'zhan', 'se', 'min', 'yu', 'ju', 'chen', 'lai', 'wen', 'sheng', 'wei',
  0x20 => 'tian', 'chu', 'zuo', 'beng', 'cheng', 'hu', 'qi', 'e', 'kun', 'chang', 'qi', 'beng', 'wan', 'lu', 'cong', 'guan',
  0x30 => 'yan', 'diao', 'bei', 'lin', 'qin', 'pi', 'pa', 'que', 'zhuo', 'qin', 'fa', 'jin', 'qiong', 'du', 'jie', 'hun',
  0x40 => 'yu', 'mao', 'mei', 'chun', 'xuan', 'ti', 'xing', 'dai', 'rou', 'min', 'jian', 'wei', 'ruan', 'huan', 'xie', 'chuan',
  0x50 => 'jian', 'zhuan', 'chang', 'lian', 'quan', 'xia', 'duan', 'yuan', 'ya', 'nao', 'hu', 'ying', 'yu', 'huang', 'rui', 'se',
  0x60 => 'liu', 'shi', 'rong', 'suo', 'yao', 'wen', 'wu', 'zhen', 'jin', 'ying', 'ma', 'tao', 'liu', 'tang', 'li', 'lang',
  0x70 => 'gui', 'zhen', 'qiang', 'cuo', 'jue', 'zhao', 'yao', 'ai', 'bin', 'shu', 'chang', 'kun', 'zhuan', 'cong', 'jin', 'yi',
  0x80 => 'cui', 'cong', 'qi', 'li', 'ying', 'suo', 'qiu', 'xuan', 'ao', 'lian', 'men', 'zhang', 'yin', 'hua', 'ying', 'wei',
  0x90 => 'lu', 'wu', 'deng', 'xiu', 'zeng', 'xun', 'qu', 'dang', 'lin', 'liao', 'qiong', 'su', 'huang', 'gui', 'pu', 'jing',
  0xA0 => 'fan', 'jin', 'liu', 'ji', 'hui', 'jing', 'ai', 'bi', 'can', 'qu', 'zao', 'dang', 'jiao', 'gun', 'tan', 'hui',
  0xB0 => 'huan', 'se', 'sui', 'tian', 'chu', 'yu', 'jin', 'lu', 'bin', 'shu', 'wen', 'zui', 'lan', 'xi', 'zi', 'xuan',
  0xC0 => 'ruan', 'wo', 'gai', 'lei', 'du', 'li', 'zhi', 'rou', 'li', 'zan', 'qiong', 'ti', 'gui', 'sui', 'la', 'long',
  0xD0 => 'lu', 'li', 'zan', 'lan', 'ying', 'mi', 'xiang', 'qiong', 'guan', 'dao', 'zan', 'huan', 'gua', 'bo', 'die', 'bo',
  0xE0 => 'hu', 'zhi', 'piao', 'ban', 'rang', 'li', 'wa', 'Dekaguramu ', 'xiang', 'qian', 'ban', 'pen', 'fang', 'dan', 'weng', 'ou',
  0xF0 => 'Deshiguramu ', 'Miriguramu ', 'wa', 'hu', 'ling', 'yi', 'ping', 'ci', 'bai', 'juan', 'chang', 'chi', 'Sarake ', 'dang', 'meng', 'bu',
];
